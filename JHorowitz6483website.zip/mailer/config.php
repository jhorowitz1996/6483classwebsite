<?php

$my_email = 'my@email.com';

$SMTP = array(
    'enabled' => true,
    'host' => 'smtp.gmail.com',
    'username' => 'user@gmail.com',
    'password' => 'password12345',
    'port' => 465,
    'encryption' => 'ssl'
);
